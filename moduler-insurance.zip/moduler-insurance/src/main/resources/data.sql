

insert into insurance (id, deleted, minimum_coverage, maximum_coverage, risk, name) values (1, false, 0,
3000, 0.30, 'Bike');

insert into insurance (id, deleted, minimum_coverage, maximum_coverage, risk, name) values (2, false, 500,
10000, 0.05, 'Jewelry');

insert into insurance (id, deleted, minimum_coverage, maximum_coverage, risk, name) values (3, false, 500,
6000, 0.35, 'Electronics');

insert into insurance (id, deleted, minimum_coverage, maximum_coverage, risk, name) values (4, false, 0,
20000, 0.30, 'Sports Equipament'); 