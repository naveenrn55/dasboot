package com.element.insurance.service.insurance;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ReflectionUtils;

import com.element.insurance.exception.ConstraintsViolationException;
import com.element.insurance.exception.EntityNotFoundException;
import com.element.insurance.model.Insurance;
import com.element.insurance.repository.InsuranceRepository;

@Service
public class InsuranceServiceImpl implements InsuranceService {
	
	private static final Logger LOG = LoggerFactory.getLogger(InsuranceServiceImpl.class);
	private InsuranceRepository insuranceRepository;

	@Autowired
	public InsuranceServiceImpl(InsuranceRepository moduleRepository) {
		this.insuranceRepository = moduleRepository;
	}

	@Override
	public List<Insurance> findAll(Pageable pageable) {
		return insuranceRepository.findAllByDeletedFalse(pageable);
	}

	@Override
	@Transactional
	public Insurance save(Insurance insuranceToCreate)  throws ConstraintsViolationException {
		Insurance insuranceModule = null;
        try {
        	insuranceModule = insuranceRepository.save(insuranceToCreate);
        }
        catch (DataIntegrityViolationException e) {
            LOG.warn("ConstraintsViolationException while creating a insurance module: {}", insuranceModule, e);
            throw new ConstraintsViolationException(e.getMessage());
        }
        return insuranceModule;	
	}

	@Override
	@Transactional
	public Insurance update(Long id, Insurance insuranceToUpdate) throws EntityNotFoundException {
		return insuranceRepository.findById(id).map(insurance -> {
			insurance.setName(insuranceToUpdate.getName());
			insurance.setMinimumCoverage(insuranceToUpdate.getMinimumCoverage());
			insurance.setMaximumCoverage(insuranceToUpdate.getMaximumCoverage());
			insurance.setRisk(insuranceToUpdate.getRisk());
			return insuranceRepository.save(insurance);
		}).orElseThrow(() -> new EntityNotFoundException("Could not find entity with id: " + id));
	}
	
	@Override
	@Transactional
	public void delete(Long id) throws EntityNotFoundException {
		Insurance insurance = insuranceRepository.findById(id)
	            .orElseThrow(() -> new EntityNotFoundException("Could not find entity with id: " + id));
		insurance.setDeleted(true);
		insuranceRepository.save(insurance);
	}

	@Override
	@Transactional
	public Insurance partialUpdate(Long id, Map<String, Object> fields)
			throws EntityNotFoundException {
		Insurance insuranceModule = insuranceRepository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("Could not find entity with id: " + id));
		fields.forEach((k, v) -> {
	       // use reflection to get field k on InsuranceModule and set it to value k
			if(v != null) {
		        Field field = ReflectionUtils.findField(Insurance.class, k);
		        ReflectionUtils.setField(field, insuranceModule, v);
			}
	    });
		
		insuranceRepository.save(insuranceModule);
		return null;
	}
}