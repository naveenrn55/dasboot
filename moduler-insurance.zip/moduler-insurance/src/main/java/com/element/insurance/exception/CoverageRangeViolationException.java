package com.element.insurance.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST, reason = "Entered Coverage is not within the range of Mudular Insurance")
public class CoverageRangeViolationException extends Exception {

	private static final long serialVersionUID = -4480938614745598570L;

	public CoverageRangeViolationException() {
		super();
	}

	public CoverageRangeViolationException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
	}

	public CoverageRangeViolationException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public CoverageRangeViolationException(String arg0) {
		super(arg0);
	}

	public CoverageRangeViolationException(Throwable arg0) {
		super(arg0);
	}

	
}
