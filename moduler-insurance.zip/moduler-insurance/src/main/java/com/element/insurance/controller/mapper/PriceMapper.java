package com.element.insurance.controller.mapper;

import java.util.List;
import java.util.stream.Collectors;

import com.element.insurance.dto.PriceDTO;
import com.element.insurance.model.Price;

public class PriceMapper {

	public static Price mapPrice(PriceDTO priceDto) {
		return new Price(0l, InsuranceMapper.mapInsurance(priceDto.getInsuranceModule()), 
				priceDto.getCoverage(), priceDto.getPrice());
	}

	public static PriceDTO mapPriceDTO(Price price) {
		PriceDTO.CalculatedInsuranceDTOBuilder calculatedInsuranceDTOBuilder = PriceDTO.newBuilder()
				.setId(price.getId())
				.setCoverage(price.getCoverage())
				.setPrice(price.getPrice())
				.setInsuranceModule(InsuranceMapper.mapInsuranceDTO(price.getInsuranceModule()));
		return calculatedInsuranceDTOBuilder.createCalculatedInsuranceDTO();
	}

	public static List<PriceDTO> mapPriceDTO(List<Price> price) {
		return price.stream()
				.map(PriceMapper::mapPriceDTO)
				.collect(Collectors.toList());
	}
}
