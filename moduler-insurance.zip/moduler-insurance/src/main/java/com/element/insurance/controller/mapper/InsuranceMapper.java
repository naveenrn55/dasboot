package com.element.insurance.controller.mapper;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import com.element.insurance.dto.InsuranceDTO;
import com.element.insurance.model.Insurance;

public class InsuranceMapper {
	
	public static Insurance mapInsurance(InsuranceDTO insuranceDTO) {
		return new Insurance(insuranceDTO.getId(), insuranceDTO.getName(), insuranceDTO.getMinimumCoverage(), 
				insuranceDTO.getMaximumCoverage(), insuranceDTO.getRisk());
	}
	
	public static InsuranceDTO mapInsuranceDTO(Insurance insurance) {
		InsuranceDTO.InsuranceModuleDTOBuilder insuranceDTOBuilder = InsuranceDTO.newBuilder()
				.setId(insurance.getId())
				.setName(insurance.getName())
				.setMinimumCoverage(insurance.getMinimumCoverage())
				.setMaximumCoverage(insurance.getMaximumCoverage())
				.setRisk(insurance.getRisk());
		
		return insuranceDTOBuilder.createInsuranceModuleDTO();
	}

	public static List<InsuranceDTO> mapInsuranceDTOList(Collection<Insurance> insurances) {
		return insurances.stream()
				.map(InsuranceMapper::mapInsuranceDTO)
				.collect(Collectors.toList());
	}
}
