package com.element.insurance.service.price;

import java.util.List;

import org.springframework.data.domain.Pageable;

import com.element.insurance.exception.CoverageRangeViolationException;
import com.element.insurance.exception.EntityNotFoundException;
import com.element.insurance.model.Price;

public interface PriceService {

	Price calculatePrice(Long id, double coverage) throws EntityNotFoundException, CoverageRangeViolationException;
	
	List<Price> findPrices(Pageable pageable);
}
