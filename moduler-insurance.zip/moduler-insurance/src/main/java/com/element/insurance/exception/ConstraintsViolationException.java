package com.element.insurance.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST, reason = "Constrain violation")
public class ConstraintsViolationException extends Exception
{

	private static final long serialVersionUID = 2555227626828291126L;

	public ConstraintsViolationException() {
		super();
	}

	public ConstraintsViolationException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
	}

	public ConstraintsViolationException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public ConstraintsViolationException(String arg0) {
		super(arg0);
	}

	public ConstraintsViolationException(Throwable arg0) {
		super(arg0);
	}


}
