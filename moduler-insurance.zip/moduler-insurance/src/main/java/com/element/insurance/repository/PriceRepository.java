package com.element.insurance.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.element.insurance.model.Price;

public interface PriceRepository extends JpaRepository<Price, Long>{

}
