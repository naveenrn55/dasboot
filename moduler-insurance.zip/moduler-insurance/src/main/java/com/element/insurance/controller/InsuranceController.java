package com.element.insurance.controller;

import java.util.List;
import java.util.Map;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.element.insurance.controller.mapper.InsuranceMapper;
import com.element.insurance.dto.InsuranceDTO;
import com.element.insurance.exception.ConstraintsViolationException;
import com.element.insurance.exception.EntityNotFoundException;
import com.element.insurance.model.Insurance;
import com.element.insurance.service.insurance.InsuranceService;

@RestController
@RequestMapping(value="/insurances")
public class InsuranceController {

	@Autowired
	private InsuranceService insuranceService;
	
	@Autowired
    private ModelMapper mapper;
	
	@GetMapping
	public List<InsuranceDTO> findAll(Pageable pageable){
		return InsuranceMapper.mapInsuranceDTOList(insuranceService.findAll(pageable));
	}
	
	@PostMapping
    @ResponseStatus(HttpStatus.CREATED)
	public InsuranceDTO create(@RequestBody InsuranceDTO insuranceToCreateDTO) throws ConstraintsViolationException {
		Insurance insuranceModule = InsuranceMapper.mapInsurance(insuranceToCreateDTO);
		Insurance insuranceSaved = insuranceService.save(insuranceModule);
		return mapper.map(insuranceSaved, InsuranceDTO.class);
	}
	
	@PutMapping("/{id}")
	public InsuranceDTO update(@PathVariable Long id, @RequestBody InsuranceDTO updateInsuranceDTO)
			 throws EntityNotFoundException {
		Insurance insuranceModule = InsuranceMapper.mapInsurance(updateInsuranceDTO);
		return InsuranceMapper.mapInsuranceDTO(insuranceService.update(id, insuranceModule));
	}
	
	@PatchMapping("/{id}")
	public InsuranceDTO partialUpdate(@PathVariable Long id, @RequestBody Map<String, Object> fields)
			 throws EntityNotFoundException {
		return InsuranceMapper.mapInsuranceDTO(insuranceService.partialUpdate(id, fields));
	}
	
	@DeleteMapping("/{id}")
	public void delete(@PathVariable Long id) throws EntityNotFoundException {
		insuranceService.delete(id);
	}
	
}
