package com.element.insurance.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST, reason = "Invalid input data")
public class InvalidParamException extends Exception {

	private static final long serialVersionUID = -2231682830816822934L;

	public InvalidParamException() {
		super();
	}

	public InvalidParamException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
	}

	public InvalidParamException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public InvalidParamException(String arg0) {
		super(arg0);
	}

	public InvalidParamException(Throwable arg0) {
		super(arg0);
	}

	
}
