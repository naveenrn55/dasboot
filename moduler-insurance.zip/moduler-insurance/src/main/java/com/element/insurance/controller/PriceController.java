package com.element.insurance.controller;

import java.util.List;

import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.element.insurance.controller.mapper.PriceMapper;
import com.element.insurance.dto.PriceDTO;
import com.element.insurance.dto.PriceInput;
import com.element.insurance.exception.CoverageRangeViolationException;
import com.element.insurance.exception.EntityNotFoundException;
import com.element.insurance.exception.InvalidParamException;
import com.element.insurance.model.Price;
import com.element.insurance.service.price.PriceService;

@RestController
@RequestMapping(value="/price")
public class PriceController {

	@Autowired
	private PriceService priceService;

	@PostMapping(value="/calculate-price")
	public PriceDTO calculateInsurancePrice(@RequestBody PriceInput input) throws EntityNotFoundException, InvalidParamException, CoverageRangeViolationException {
		if(input.getCoverage() < 0) {
			throw new InvalidParamException("Coverage could not be negative");
		}
		Price calculateInsurancePrice = priceService.calculatePrice(input.getId(), input.getCoverage());
		return PriceMapper.mapPriceDTO(calculateInsurancePrice);
		
	}
	
	@GetMapping
	public List<PriceDTO> findAllPrices(Pageable pageable){
		return PriceMapper.mapPriceDTO(priceService.findPrices(pageable));
	}
}
