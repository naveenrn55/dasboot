package com.element.insurance.service.insurance;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Pageable;

import com.element.insurance.exception.ConstraintsViolationException;
import com.element.insurance.exception.EntityNotFoundException;
import com.element.insurance.model.Insurance;

public interface InsuranceService {
	
	List<Insurance> findAll(Pageable pageable);

	Insurance save(Insurance insuranceToCreate) throws ConstraintsViolationException;

	Insurance update(Long id, Insurance insuranceToUpdate) throws EntityNotFoundException;
	
	Insurance partialUpdate(Long id, Map<String, Object> updates) throws EntityNotFoundException;

	void delete(Long id) throws EntityNotFoundException;
	
}
