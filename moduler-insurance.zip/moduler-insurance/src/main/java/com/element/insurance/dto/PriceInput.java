package com.element.insurance.dto;

public class PriceInput {
	
	private Long id;
	private double coverage;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public double getCoverage() {
		return coverage;
	}
	public void setCoverage(double coverage) {
		this.coverage = coverage;
	}
	
	

}
