package com.element.insurance.service.price;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.element.insurance.exception.CoverageRangeViolationException;
import com.element.insurance.exception.EntityNotFoundException;
import com.element.insurance.exception.InvalidParamException;
import com.element.insurance.model.Price;
import com.element.insurance.model.Insurance;
import com.element.insurance.repository.PriceRepository;
import com.element.insurance.repository.InsuranceRepository;

@Service
public class PriceServiceImpl implements PriceService {
	
	private InsuranceRepository insuranceModuleRepository;
	
	private PriceRepository calculatedInsuranceRepository;
	
	@Autowired
	public PriceServiceImpl(
			InsuranceRepository insuranceModuleRepository,
			PriceRepository calculatedInsuranceRepository) {
		this.insuranceModuleRepository = insuranceModuleRepository;
		this.calculatedInsuranceRepository = calculatedInsuranceRepository;
	}


	@Override
	@Transactional
	public Price calculatePrice(Long id, double coverage) throws EntityNotFoundException, CoverageRangeViolationException {
		Insurance insurance = insuranceModuleRepository.findById(id)
	            .orElseThrow(() -> new EntityNotFoundException("Could not find entity with id: " + id));
		if(isCoverageWithinLimit(insurance,coverage)) {
			throw new CoverageRangeViolationException("Coverage Range Violation");
		}
		double price = coverage * insurance.getRisk();
		Price calculatedInsurance = new Price(0l, insurance, coverage, price);
		return calculatedInsuranceRepository.save(calculatedInsurance);
	}

	private boolean isCoverageWithinLimit(Insurance insurance, double coverage) {
		if(insurance.getMinimumCoverage()>=coverage && insurance.getMaximumCoverage()<=coverage) {
			return true;
		}
		return false;
	}


	@Override
	public List<Price> findPrices(Pageable pageable) {
		return calculatedInsuranceRepository.findAll(pageable).getContent();
	}

}
