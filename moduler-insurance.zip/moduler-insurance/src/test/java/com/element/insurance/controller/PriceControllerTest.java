package com.element.insurance.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.element.insurance.dto.InsuranceDTO;
import com.element.insurance.dto.PriceDTO;
import com.element.insurance.dto.PriceInput;
import com.element.insurance.model.Insurance;
import com.element.insurance.model.Price;
import com.element.insurance.service.price.PriceService;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

@RunWith(SpringRunner.class)
@WebMvcTest(PriceController.class)
public class PriceControllerTest {

	@MockBean
	private PriceService priceService;

	@Autowired
	private MockMvc mvc;

	private JacksonTester<List<PriceDTO>> jsonList;
	private JacksonTester<PriceDTO> json;

	@Before
	public void setup() {
		JacksonTester.initFields(this, new ObjectMapper());
	}

	@Test
	public void findAllCalculatedInsuranceTest() throws Exception {
		Pageable pageable = PageRequest.of(0, 20);
		Insurance insurance = new Insurance(1l, "Bike", 0, 3000, 0.3);
		Price calculatedInsurance = new Price(1l, insurance, 1000, 300);
		List<Price> calculatedList = new ArrayList<>();
		Collections.addAll(calculatedList, calculatedInsurance);
		InsuranceDTO insuranceDTO = new InsuranceDTO(1l, "Bike", 0, 3000, 0.3);
		PriceDTO calculatedDTO = new PriceDTO(1l, 1000.0, 300.0, insuranceDTO);
		List<PriceDTO> calculatedDTOList = new ArrayList<>();
		Collections.addAll(calculatedDTOList, calculatedDTO);

		given(priceService.findPrices(pageable)).willReturn(calculatedList);
		MockHttpServletResponse response = mvc.perform(get("/price").accept(MediaType.APPLICATION_JSON)).andReturn()
				.getResponse();
		assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
		assertThat(response.getContentAsString()).isEqualTo(jsonList.write(calculatedDTOList).getJson());
	}

	@Test
	public void calculateInsurancePriceTest() throws Exception {
		Insurance insurance = new Insurance(1l, "Test", 0, 3000, 0.3);
		Price calculatedInsurance = new Price(1l, insurance, 1000, 300);
		InsuranceDTO insuranceDTO = new InsuranceDTO(1l, "Test", 0, 3000, 0.3);
		PriceInput input = new PriceInput();
		input.setId(1L);
		input.setCoverage(1000.0);
		PriceDTO calculatedDTO = new PriceDTO(1l, 1000.0, 300.0, insuranceDTO);
		given(priceService.calculatePrice(1L, 1000.0)).willReturn(calculatedInsurance);
		MockHttpServletResponse response = mvc
				.perform(post("/price/calculate-price")
						.content(convertObjectToJsonBytes(input)).contentType(MediaType.APPLICATION_JSON))
				.andReturn().getResponse();
		assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
		assertThat(response.getContentAsString()).isEqualTo(json.write(calculatedDTO).getJson());
	}

	@Test
	public void calculateInsurancePriceTestWithNegativeValue() throws Exception {
		PriceInput input = new PriceInput();
		input.setId(1L);
		input.setCoverage(-10);
		MockHttpServletResponse response = mvc
				.perform(post("/price/calculate-price")
						.content(convertObjectToJsonBytes(input)).contentType(MediaType.APPLICATION_JSON))
				.andReturn().getResponse();
		assertThat(response.getStatus()).isEqualTo(HttpStatus.BAD_REQUEST.value());
	}

	
	public static byte[] convertObjectToJsonBytes(Object object) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		mapper.disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
		List<Object> list = new ArrayList<Object>();
		list.add(object);
		return mapper.writeValueAsBytes(object);
	}
}
