package com.element.insurance.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.element.insurance.dto.InsuranceDTO;
import com.element.insurance.model.Insurance;
import com.element.insurance.service.insurance.InsuranceService;

@RunWith(SpringRunner.class)
@WebMvcTest(InsuranceController.class)
public class InsuranceControllerTest {

	@MockBean
	private InsuranceService insuranceService;
	
	@MockBean
	private ModelMapper modelMapper;

	@Autowired
	private MockMvc mvc;

	@Test
	public void findAllTest() throws Exception {
		Pageable pageable = PageRequest.of(0, 20);
		Insurance insurance = new Insurance(1l, "Bike", 0, 3000,
				0.3);
		List<Insurance> insuranceList = new ArrayList<>();
		Collections.addAll(insuranceList, insurance);
		InsuranceDTO insuranceDTO = new InsuranceDTO(1l, "Bike", 0,
				3000, 0.3);
		List<InsuranceDTO> insuranceDTOList = new ArrayList<>();
		Collections.addAll(insuranceDTOList, insuranceDTO);

		given(insuranceService.findAll(pageable))
				.willReturn(insuranceList);
		
		MockHttpServletResponse response = mvc
				.perform(
						get("/insurances").accept(
								MediaType.APPLICATION_JSON)).andReturn()
				.getResponse();
		
		assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
		assertNotNull(response.getContentAsString());
		assertTrue(response.getContentAsString().contains("Bike"));
	}
	
}
