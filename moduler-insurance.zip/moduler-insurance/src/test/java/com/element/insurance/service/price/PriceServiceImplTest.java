package com.element.insurance.service.price;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.mockito.BDDMockito.given;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import com.element.insurance.exception.CoverageRangeViolationException;
import com.element.insurance.exception.EntityNotFoundException;
import com.element.insurance.model.Price;
import com.element.insurance.model.Insurance;
import com.element.insurance.repository.PriceRepository;
import com.element.insurance.service.price.PriceServiceImpl;
import com.element.insurance.repository.InsuranceRepository;

public class PriceServiceImplTest {

	private PriceServiceImpl calculatedInsuranceServiceImpl;

	@Mock
	private PriceRepository calculatedInsuranceRepository;
	@Mock
	private InsuranceRepository insuranceRepository;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		calculatedInsuranceServiceImpl = new PriceServiceImpl(
				insuranceRepository, calculatedInsuranceRepository);
	}
	
	@Test
	public void findCalculatedInsurancesTest() {
		Insurance insurance = new Insurance(1l, "Bike", 0, 3000, 0.3);
		Price calculatedInsurance = new Price(1l, insurance, 1000, 300);
		List<Price> calculatedInsuranceList = new ArrayList<>();
		Collections.addAll(calculatedInsuranceList, calculatedInsurance);
		Page<Price> page = new PageImpl<Price>(calculatedInsuranceList);
		Pageable pageable = PageRequest.of(0, 20);
		given(calculatedInsuranceRepository.findAll(pageable)).willReturn(page);
		List<Price> returnedList = calculatedInsuranceServiceImpl.findPrices(pageable);
		assertThat(returnedList).isEqualTo(calculatedInsuranceList);
	}
	
	@Test
	public void findEmptyCalculatedInsurancesTest() {
		List<Price> calculatedInsuranceList = new ArrayList<>();
		Page<Price> page = new PageImpl<Price>(calculatedInsuranceList);
		Pageable pageable = PageRequest.of(0, 20);
		given(calculatedInsuranceRepository.findAll(pageable)).willReturn(page);
		List<Price> returnedList = calculatedInsuranceServiceImpl.findPrices(pageable);
		assertThat(returnedList).isEqualTo(calculatedInsuranceList);
	}
	
	@Test(expected=EntityNotFoundException.class)
	public void calculatePriceTestWithError() throws EntityNotFoundException, CoverageRangeViolationException {
		Optional<Insurance> optional = Optional.empty();
		given(insuranceRepository.findById(1L)).willReturn(optional);
		calculatedInsuranceServiceImpl.calculatePrice(1L, 1000.0);
	}
	
	@Test
	public void calculatePriceTest() throws EntityNotFoundException, CoverageRangeViolationException {
		Insurance insurance = new Insurance(1l, "Sports", 0, 3000.0, 0.5);
		Optional<Insurance> optional = Optional.ofNullable(insurance);
		Price calculatedInsurance = new Price(0l, insurance, 1000.0, 500.0);
		Price savedCalculated = new Price(1l, insurance, 1000.0, 500.0);
		given(insuranceRepository.findById(4L)).willReturn(optional);
		given(calculatedInsuranceRepository.save(Mockito.any())).willReturn(savedCalculated);
		Price price = calculatedInsuranceServiceImpl.calculatePrice(4L, 1000.0);
		assertThat(price).isEqualTo(savedCalculated);
		assertEquals(price.getPrice(), 500.0, 0.1);
	}
}
