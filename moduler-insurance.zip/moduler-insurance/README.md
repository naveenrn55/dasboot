
## How to use

To run, use the command below:

> mvn spring-boot:run

To make a request, use a command with curl like 

> curl -v http://localhost:8080/insurances

Or swagger is available at

> http://localhost:8080/swagger-ui.html

The modules described in the task above are already stored in the database. 

Simple UI url : http://localhost:8080/index.html
