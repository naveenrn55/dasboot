package com.mindtree.review.management.reviewmanagementservice;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
public class ReviewManagementServiceApplicationTests {

	@Test
	public void contextLoads() {
	}

}
