insert into review_rating (review_id,restaurant_id,customer_email,comments,rating,reviewed_date,like_count,dislike_count) values (1,100,'user@example.com','Nice',4,{ts '2012-09-17 18:47:52.69'},0,0);
insert into review_rating (review_id,restaurant_id,customer_email,comments,rating,reviewed_date,like_count,dislike_count) values (2,100,'user1@example.com','Awesome',4,{ts '2012-09-17 18:47:52.69'},0,0);

insert into review_rating (review_id,restaurant_id,customer_email,comments,rating,reviewed_date,like_count,dislike_count) values (3,101,'user1@example.com','Awesome',4,{ts '2012-09-17 18:47:52.69'},0,0);

insert into review_rating (review_id,restaurant_id,customer_email,comments,rating,reviewed_date,like_count,dislike_count) values (4,101,'user@example.com','Awesome',4,{ts '2012-09-17 18:47:52.69'},0,0);