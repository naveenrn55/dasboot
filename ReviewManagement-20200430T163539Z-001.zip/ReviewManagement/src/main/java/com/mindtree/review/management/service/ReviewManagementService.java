/**
 * 
 */
package com.mindtree.review.management.service;

import java.util.List;

import com.mindtree.review.management.model.Review;

/**
 * @author Ranjith Ranganathan
 *
 */

public interface ReviewManagementService {
    
    public List<Review> getAllReviews();
    
    public List<Review> getReviewByRestaurantId(String restaurantId);
    
    public List<Review> getReviewByCustomerEmail(String custEmail, Integer pageNumber, Integer count);
    
    public Review getReviewByRstIdAndEmail(String restaurantId, String custEmail);
    
    public Review addNewReview(Review review, String custEmail);
    
    public Review getReviewById(Long reviewId);
   
    public boolean removeReview(String restaurantId, String email);
    
    public Review updateReview(Review review, String custEmail);
    
    public boolean updateLikeCount(Long reviewId);
    
    public boolean updateDisLikeCount(Long reviewId);

}
